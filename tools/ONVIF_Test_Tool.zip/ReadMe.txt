


1. Application Name and Version
======================================

ONVIF Test Tool v 12.12



2. System Requirements
======================================

	1. Windows XP / Windows 7

	2. .NET Framework 3.5 SP1
	



3. Installation Instructions:
======================================

	1. Please read 'ONVIF_Device_TestTool_v12.12_Installation_Guide.pdf' file for detailed instructions.

	2. Run setup.exe and follow installer instructions.
	
	3. After installation complete, go to Start->Program->ONVIF menu and run aplication.

	4. Please read 'ONVIF_Test_Tool_Release_Notes_vHeineken.121227.pdf' file for description of this version.

	5. It would be highly appreciated if you provide your feedback (found bugs) to ONVIF WG Test Tool: onvif_tsc_wgmaintenance@mail.onvif.org.
